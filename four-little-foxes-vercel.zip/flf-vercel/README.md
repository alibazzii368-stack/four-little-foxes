# Four Little Foxes ☕
### Specialty Coffee & Brunch — Milperra NSW 2214

---

## 🚀 Deploy to Vercel (3 ways)

### Option 1 — Vercel Dashboard (Easiest)
1. Go to [vercel.com](https://vercel.com) and sign in
2. Click **"Add New Project"**
3. Click **"Upload"** and drag this ZIP folder
4. Click **Deploy**
5. ✅ Live in ~30 seconds at `https://your-project.vercel.app`

### Option 2 — GitHub + Vercel (Recommended for updates)
1. Push this folder to a GitHub repository
2. Go to [vercel.com](https://vercel.com) → **Add New Project**
3. Import your GitHub repo
4. Click **Deploy** — auto-deploys on every push ✅

### Option 3 — Vercel CLI
```bash
npm install -g vercel
cd four-little-foxes
vercel
```

---

## 📁 Project Structure
```
four-little-foxes/
├── public/
│   └── index.html        # Complete website (all assets embedded)
├── package.json          # Node config
├── vercel.json           # Vercel routing & headers
├── .gitignore
└── README.md
```

---

## ✨ Features
- ☕ Full specialty coffee & brunch menu (7 categories)
- 📸 Real café photos (embedded, no CDN needed)
- 🎞️ Auto-scrolling photo gallery
- 📱 Mobile-first responsive design
- 🗺️ Animated map with Get Directions button
- ⭐ Customer reviews section
- 🌙 Smooth scroll animations
- 🔒 Works fully offline (no external dependencies)

---

## 📍 Business Details
| | |
|---|---|
| **Address** | 8/48 Amiens Ave, Milperra NSW 2214 |
| **Phone** | +61 405 570 528 |
| **Website** | fourlittlefoxes.net |
| **Hours** | Mon–Fri: 6:30am–2:00pm |
| | Sat–Sun: 7:30am–2:00pm |

---

## 🛠️ Local Development
```bash
npm install
npm run dev
# Opens at http://localhost:3000
```

Or simply open `public/index.html` in any browser — no server needed.
